export const GoogleMapsAPI = 'xxxx';
